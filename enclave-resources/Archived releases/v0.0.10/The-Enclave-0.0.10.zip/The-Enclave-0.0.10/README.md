# The-Enclave
The Enclave focuses around the discovery of an isolated group of humans in a distant galaxy. Separated from the rest of their species for over half a millennium, how have these people developed?

### Special Thanks
[Derpy Horse](https://github.com/Amazinite) for creating the animated stars.
